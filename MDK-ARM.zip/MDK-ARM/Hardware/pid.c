#include "pid.h"
#include <math.h>  // 在文件顶部添加

void PID_Init(PID_t *pid, float kp, float ki, float kd)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;

    pid->integral      = 0.0f;
    pid->prev_err      = 0.0f;
    pid->prev_measured = 0.0f;   /* 首次dt较短或用户自行设定初值均可, 只影响第一次的d项 */

    pid->out_min = 0.0f;         /* 调用方按实际需要覆盖, 比如设成 -999~999 */
    pid->out_max = 100.0f;
}

float PID_Compute(PID_t *pid, float setpoint, float measured, float dt)
{
    float err = setpoint - measured;
    float p, i, d, out;

    p = pid->kp * err;
    pid->integral += err * dt;
    i = pid->ki * pid->integral;
    d = pid->kd * (err - pid->prev_err) / dt;
    pid->prev_err = err;

    out = p + i + d;

    /* 抗积分饱和：输出限幅时才允许回卷 */
    if (out > pid->out_max) {
        out = pid->out_max;
        pid->integral -= err * dt;   /* 撤销本次积分 */
    } else if (out < pid->out_min) {
        out = pid->out_min;
        pid->integral -= err * dt;
    }
    return out;
}

