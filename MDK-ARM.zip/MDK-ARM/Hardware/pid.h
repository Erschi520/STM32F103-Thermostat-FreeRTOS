#ifndef __PID_H
#define __PID_H

typedef struct {
    float kp, ki, kd;
    float integral;
    float prev_err;        /* 保留字段, 部分场景仍可能用到误差微分 */
    float prev_measured;   /* 上一次测量值, 用于"对测量值求导", 避免设定值突变造成微分冲击 */
    float out_min, out_max;
} PID_t;

void  PID_Init(PID_t *pid, float kp, float ki, float kd);
float PID_Compute(PID_t *pid, float setpoint, float measured, float dt);

#endif
