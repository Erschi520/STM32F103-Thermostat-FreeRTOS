#ifndef __SSD1306_H
#define __SSD1306_H

#include "main.h"

#define OLED_I2C_ADDR   (0x3C << 1)   /* ������ַ 0x3C */

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowString(uint8_t x, uint8_t y, char *str);       /* y: 0~7 �� */
void OLED_ShowNum(uint8_t x, uint8_t y, float num, uint8_t decimals);
void OLED_Refresh(void);
void OLED_ShowStringBig(uint8_t x, uint8_t y, char *str);   /* 12x16, yֻ��ȡ0~6 */
void OLED_ShowString8x16(uint8_t x, uint8_t y, char *str);   /* 8x16��׼����, yȡ0/2/4/6 */
#endif
